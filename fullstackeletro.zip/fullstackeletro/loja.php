<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF8">
<title>Nossas Lojas - Full Stack Eletro</title>
<link rel="Stylesheet" href="./css/estilo.css">
</head>
<body>
    <nav class="menu">
        <a href="index.php"><img width="100px%" src="./imagens/logo.png" alt="Full Stack Eletro"/></a>
        <a href="produtos.php">Nossos produtos</a>
        <a href="loja.php">Nossas lojas</a>
        <a href="contato.php">Fale conosco</a>
        </nav>
<header>
<h2>Nossas Lojas</h2>
</header>
<hr>
<table border="0" width="100%" cellpadding="20">
<tr>
<td width="33%">
<h3><font face="Arial">Rio de Janeiro</font></h3>
<p><font face="Arial">Avenida Presidente Vargas, 5000</font></p>
<p><font face="Arial"> 10º andar</font></p>
<p><font face="Arial">Centro</font></p>
<p><font face="Arial">(21) 2121-5454</font></p>
</td>

<td width="33%">
<h3><font face="Arial">São Paulo</font></h3>
<p><font face="Arial">Avenida Paulista, 985</font></p>
<p><font face="Arial"> 3º andar</font></p>
<p><font face="Arial">Jardins</font></p>
<p><font face="Arial">(11) 5578-5454</font></p>
</td>

<td width="33%">
<h3><font face="Arial">Santa Catarina</font></h3>
<p><font face="Arial">Rua Major &Aacute;vila, 370</font></p>
<p><font face="Arial">2º andar</font></p>
<p><font face="Arial">Vila Mariana</font></p>
<p><font face="Arial">(47) 8787-3232</font></p>
</td>

</tr>
</table>
<br><br><br><br><br>
<br><br><br><br><br>
<footer id="rodape">
    <p id="formas_pagamento"><b>Formas de pagamento:</b></p>
    <img src="./imagens/formas-pagamento.png" style="width:30%" alt="formas de pagamento"/>
    <p>&copy; Recode Pro</p>
    </footer>
</body>