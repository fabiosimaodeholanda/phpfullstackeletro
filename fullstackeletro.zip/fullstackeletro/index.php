<!DOCYTYPE html>
<html lang="pt-br">
<head> 
<meta charset="UTF8">
<title>Full Stack Eletro</title>
<link rel="Stylesheet" href="./css/estilo.css">
</head>
<body>

<nav class="menu">
<a href="index.php"><img width="100px%" src="./imagens/logo.png" alt="Full Stack Eletro"/></a>
<a href="produtos.php">Nossos produtos</a>
<a href="loja.php">Nossas lojas</a>
<a href="contato.php">Fale conosco</a>
</nav>
<main>
<h1><font face="Arial">Seja bem vindo</font></h1>
<p>Aqui em nossa loja, programadores tem desconto nos produtos para sua casa!</p>
</main>

<br><br><br><br><br>
<br><br><br><br><br>
<br><br><br><br><br>
<br><br><br><br><br>

<footer id="rodape">
<p id="formas_pagamento"><b>Formas de pagamento:</b></p>
<img src="./imagens/formas-pagamento.png" style="width:30%" alt="formas de pagamento"/>
<p>&copy; Recode Pro</p>
</footer>
</body>
</html>